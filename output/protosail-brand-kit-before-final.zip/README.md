# Protosail vector identity kit

Open **index.html** for the visual guide and downloads. All SVG files are self-contained vector paths; no font installation is needed. The artwork uses flat sRGB colours, without raster images, gradients, strokes, or external resources.

## Choose an asset

| File group | Use |
| --- | --- |
| icon | The two sail shapes alone. Yellow-lime, charcoal, white. |
| wordmark | Full PROTOSAIL lettering with conventional A and I. Charcoal or white. |
| primary | PROTOS + sail pair + L. Sails replace AI. |
| horizontal | Sail icon beside the full wordmark. |
| stacked | Sail icon above the full wordmark. |
| app | Rounded charcoal tile; lime icon. |
| favicon | Square charcoal tile; lime icon. |

Primary, horizontal, and stacked logos each have lime-black, lime-white, black, and white editions. Use lime-black or black on light backgrounds; lime-white or white on dark backgrounds. The lime icon is most distinct on a dark background. The primary and stacked logos also include **panel-white** editions: yellow-lime sails and white text on a charcoal rectangle with an opaque white outer border. The other ordinary logo files are transparent. App tile corner areas are transparent; the favicon tile is opaque charcoal. Filenames containing black are retained for compatibility and now use charcoal #141414.

## Geometry and spacing

- Icon height: 1000 units. Width: 997.665974 units. Main wing width: 712.665974 units.
- Gap between panel vertical edges: 65 units. Vane width: 220 units. Vane top: 330 units. Vane height: 670 units.
- Main wing edge angles: top 20°, leading 70°, foot 14°. The main trailing edge and both vane side edges are exactly vertical. Vane caps are parallel at 32°. Both rounded sail bottoms lie on y=1000.
- Main corner radii, tip / trailing foot / heel / shoulder: 25.915648 / 48.59184 / 70.188214 / 129.578241 units.
- Vane corner radii, top-left / top-right / bottom-right / bottom-left: 24 / 95 / 24 / 95 units. Circular fillets meet their straight edges tangentially.
- S is redrawn with balanced rounded bowls, level terminals, and 180-degree symmetry.
- Letter cap height: 1000 units; baseline y=1000. Main vertical stem: 310 units. O overshoots by 20 units above and below. P and R share the same bowl and counter; repeated O paths are identical.
- Kerning, in cap units: PR 20; RO -30; OT -20; TO -20; OS 20; SA 25; AI 40; IL 40. These are gaps between glyph bounding boxes, not between every visible edge.
- Integrated primary: icon height 1750, icon y=−480, S-to-icon bounding-box gap 0, icon-to-L gap 120.
- Horizontal: icon height 2500, icon y=−750, icon-to-wordmark gap 400.
- Stacked: icon height 3300, visible gap 400 above the O overshoot, artwork centred horizontally.
- App: 1000-unit square, corner radius 160, icon height 700. Favicon: square tile, icon height 760. Both use centred artwork and unchanged master sail paths.

## Clear space and minimum sizes

Supplied viewBoxes include clear space. Keep at least that much room outside the visible artwork. Do not crop this padding when positioning neighbouring content.

- Icon: 250 units on every side, one-quarter of icon height. Recommended minimum file width: 32 px.
- Lettered compositions: 500 units on every side, half a letter cap height.
- Recommended minimum file widths including padding: primary 200 px; wordmark 160 px; horizontal 240 px; stacked 180 px.
- Favicon minimum: 16 × 16 px. At 16 px the panel gap is subpixel-antialiased; use 32 px or above where space permits. ICO contains 16, 32, and 48 px PNG-compressed entries.
- Tile margins are built in and differ from the ordinary logo clear-space rule. Panel-white editions contain 500 units of charcoal clear space plus a 250-unit white border; minimum widths are 220 px for primary and 200 px for stacked.

## Formats

- **svg/** — 21 scalable, editable files. The icon paths and letter paths can be selected in a vector editor. All transforms are translations or uniform scales.
- **png/** — ordinary logos at 512 and 2048 px wide; app icons at 192 and 512 px; favicons at 16, 32, and 48 px. Width includes clear space; height is rounded to the nearest whole pixel with uniform fitting.
- **protosail-favicon.ico** — 16/32/48 px multi-size favicon.
- **preview.png** — overview of the complete system.
- **geometry.json** — canonical paths, layout data, glyph placements, and asset dimensions.
- **source/build-brand.mjs** — reproducible source; canonical working copy is scripts/build-brand.mjs in the project.
- **manifest.json** — SHA-256 checksums of packaged files (excluding itself and the ZIP).
- **protosail-brand-kit.zip** — the complete kit; does not contain a recursive copy of itself.

## Colours

Yellow-lime **#E3F941**, charcoal **#141414**, white **#FFFFFF**. Lime is an approximate sample from the supplied AI reference and is deliberately flattened to one colour. No spot-ink or CMYK match is asserted. A print provider can colour-match the vector artwork for its process.

## Editing and regeneration

Scale entire compositions proportionally; preserve the viewBox. Do not retype the wordmark or reshape one sail separately. No website integration is performed by this kit.

From the original project, run:

    node scripts/build-brand.mjs

Chrome and the project's installed puppeteer-core are used for PNG/proof exports. Set the CHROME environment variable to override the default Windows Chrome location. For vectors, JSON, and documentation only:

    node scripts/build-brand.mjs --svg-only

Edit the canonical geometry or layout constants in scripts/build-brand.mjs and regenerate all outputs together. Manual edits to generated files will be overwritten. Regeneration is byte-stable within the same Node/Chrome environment; a different renderer version may change PNG antialiasing.

In HTML, use an img element with meaningful alternative text, e.g. alt="Protosail" for a homepage logo. Use empty alt text for a purely decorative repeat. Set width and height through CSS while preserving aspect ratio.
